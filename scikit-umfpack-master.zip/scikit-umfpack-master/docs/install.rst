Installation
============

.. include:: ../README.rst
  :start-after: include-start
  :end-before: include-end
